export function CogentLogo() {
    return <div className="logo">COGENT</div>;
  }
  
  export function FinastraLogo() {
    return <div className="logo">FINASTRA</div>;
  }