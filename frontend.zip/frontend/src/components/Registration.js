import React, { useState } from 'react';

const Registration = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    jobTitle: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit logic here
  };

  return (
    <section id="register" className="registration">
      <div className="container">
        <h2>Register Now</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <input 
              type="text" 
              placeholder="Full Name" 
              required 
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="form-group">
            <input 
              type="email" 
              placeholder="Email" 
              required
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
            />
          </div>
          <button type="submit" className="btn-primary">Submit Registration</button>
        </form>
      </div>
    </section>
  );
};

export default Registration;