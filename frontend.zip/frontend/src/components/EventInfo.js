import React from 'react';

const EventInfo = () => {
  return (
    <section id="about" className="event-info">
      <div className="container">
        <h2>About the Event</h2>
        <p>Join us for an exclusive in-person event where we'll explore how banks can reimagine...</p>
        
        <div className="info-cards">
          <div className="info-card">
            <h3>Who Should Attend</h3>
            <ul>
              <li>Retail Banking Executives</li>
              <li>Heads of Digital Transformation</li>
              <li>CIOs/CTOs</li>
            </ul>
          </div>
          
          <div className="info-card">
            <h3>Key Topics</h3>
            <ul>
              <li>Digital Transformation</li>
              <li>Cloud Banking</li>
              <li>Open Finance</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EventInfo;