import { CogentLogo, FinastraLogo } from './Logos';

export default function Header() {
  return (
    <header style={{
      display: 'flex',
      justifyContent: 'space-between',
      padding: '20px',
      backgroundColor: '#f0f0f0'
    }}>
      <CogentLogo />
      <FinastraLogo />
    </header>
  );
}