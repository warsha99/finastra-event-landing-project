import React from 'react';

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Reimagine Banking</h1>
        <p>23 November 2023 | Dusit Thani, Dubai</p>
        <div className="hero-buttons">
          <button className="btn-primary">Register Now</button>
          <button className="btn-outline">Download Brochure</button>
        </div>
      </div>
    </section>
  );
};

export default Hero;