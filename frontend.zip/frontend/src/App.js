import logo from './logo.svg';
import './App.css';
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import EventInfo from './components/EventInfo';
import Speakers from './components/Speakers';
import Agenda from './components/Agenda';
import Registration from './components/Registration';
import Footer from './components/Footer';
import './styles/main.css';


function App() {
  return (
    <div className="App">
      <Header />
      <Hero />
      <EventInfo />
      <Speakers />
      <Agenda />
      <Registration />
      <Footer />
    </div>
  );
}

export default App;
